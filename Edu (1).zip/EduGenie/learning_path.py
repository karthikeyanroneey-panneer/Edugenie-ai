"""Personalized learning-path module."""

from gemini_client import generate_text


def get_learning_recommendations(topic: str, level: str = "Beginner") -> str:
    prompt = f"""
Create a structured learning path for:

Topic: {topic}
Learner level: {level}

Organize the path from foundational concepts to advanced topics.
For each stage include:
- What to learn
- Suggested sequence
- A practical activity or mini-project
- A realistic study-time estimate

Also provide general suggestions for finding useful videos, articles,
documentation, books, or practice exercises. Do not invent specific URLs.
End with a short "Next step" section.
""".strip()

    return generate_text(
        prompt,
        system_instruction=(
            "You are EduGenie, a personalized educational planning assistant. "
            "Adapt the depth and vocabulary to the learner's level."
        ),
        temperature=0.45,
        max_output_tokens=2500,
    )
