"""Question-answering module."""

from gemini_client import generate_text

SYSTEM_PROMPT = """
You are EduGenie, a friendly educational assistant.
Answer student questions accurately and clearly.
Use simple language appropriate for learners.
For academic questions, explain the reasoning when useful.
Do not invent sources, quotations, facts, or citations.
If a question is ambiguous, state the assumption you are making.
Keep answers concise unless the user asks for detail.
""".strip()


def answer_question(question: str) -> str:
    prompt = f"""
Answer this student's question:

{question}

Give a direct answer first, followed by a short explanation if appropriate.
""".strip()

    return generate_text(
        prompt,
        system_instruction=SYSTEM_PROMPT,
        temperature=0.3,
        max_output_tokens=1200,
    )
