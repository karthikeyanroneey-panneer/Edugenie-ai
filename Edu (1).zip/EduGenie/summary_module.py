"""Educational summarization module."""

from gemini_client import generate_text


def summarize_text(text: str) -> str:
    prompt = f"""
Summarize the following educational passage for quick revision.

Requirements:
- Preserve the important facts and meaning.
- Remove repetition and unnecessary detail.
- Use short paragraphs or bullet points.
- Do not introduce facts that are absent from the passage.

Passage:
{text}
""".strip()

    return generate_text(
        prompt,
        system_instruction=(
            "You are EduGenie, an educational summarization assistant. "
            "Be accurate, concise, and easy to understand."
        ),
        temperature=0.25,
        max_output_tokens=1800,
    )
