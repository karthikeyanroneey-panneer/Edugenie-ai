"""Quiz generation module with structured JSON output."""

import json
import re

from gemini_client import generate_text


def clean_json_block(text: str) -> str:
    """Remove Markdown fences and isolate a JSON object/array."""
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    return cleaned.strip()


def _fallback_parse(text: str):
    cleaned = clean_json_block(text)

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        match = re.search(r"(\[[\s\S]*\])", cleaned)
        if match:
            return json.loads(match.group(1))
        raise


def generate_quiz(passage: str) -> list[dict]:
    prompt = f"""
Create exactly 3 multiple-choice questions from the educational passage below.

Return ONLY a JSON array. Do not use Markdown.

Each array item must have exactly these fields:
- question: string
- options: an array of exactly 4 strings
- correct_answer: string
- explanation: string

The correct_answer must exactly match one option.

Passage:
{passage}
""".strip()

    raw = generate_text(
        prompt,
        system_instruction=(
            "You create reliable educational MCQs. Follow the requested JSON "
            "schema exactly and never add commentary outside the JSON."
        ),
        temperature=0.2,
        max_output_tokens=2200,
    )

    quiz = _fallback_parse(raw)

    if not isinstance(quiz, list) or len(quiz) != 3:
        raise ValueError("Gemini did not return exactly three quiz questions.")

    for item in quiz:
        if not isinstance(item, dict):
            raise ValueError("Invalid quiz item.")
        if not all(k in item for k in ("question", "options", "correct_answer", "explanation")):
            raise ValueError("A quiz item is missing a required field.")
        if not isinstance(item["options"], list) or len(item["options"]) != 4:
            raise ValueError("Each quiz question must contain four options.")
        if item["correct_answer"] not in item["options"]:
            raise ValueError("The correct answer must match one of the options.")

    return quiz
