"""Concept explanation module.

The project documentation specifies LaMini-Flan-T5 as the lightweight local
explanation model. This implementation makes that model optional because
installing the transformer stack can be heavy on a beginner's machine.

Set USE_LOCAL_EXPLAINER=true and install the optional dependencies to use it.
Otherwise, Gemini provides the explanation.
"""

import os

from gemini_client import generate_text

_local_pipeline = None


def _get_local_pipeline():
    global _local_pipeline

    if _local_pipeline is not None:
        return _local_pipeline

    from transformers import pipeline

    model_name = os.getenv(
        "LOCAL_EXPLAINER_MODEL",
        "MBZUAI/LaMini-Flan-T5-783M",
    )
    _local_pipeline = pipeline(
        "text2text-generation",
        model=model_name,
        tokenizer=model_name,
    )
    return _local_pipeline


def _local_explain(topic: str) -> str:
    pipe = _get_local_pipeline()
    prompt = (
        "Explain the following educational topic in simple language for a beginner. "
        "Use a short definition, key points, and one simple example.\n\n"
        f"Topic: {topic}"
    )
    result = pipe(prompt, max_new_tokens=300, do_sample=False)
    return result[0]["generated_text"].strip()


def explain_topic(topic: str) -> str:
    use_local = os.getenv("USE_LOCAL_EXPLAINER", "false").lower() == "true"

    if use_local:
        try:
            return _local_explain(topic)
        except Exception:
            # A local model failure should not make the main application unusable.
            pass

    prompt = f"""
Explain the following topic to a beginner:

{topic}

Use this structure:
1. Simple definition
2. How it works
3. Key points
4. One easy example
5. One common mistake or misconception

Keep it clear and educational.
""".strip()

    return generate_text(
        prompt,
        system_instruction=(
            "You are EduGenie. Explain difficult concepts using simple, "
            "age-appropriate educational language."
        ),
        temperature=0.35,
        max_output_tokens=1600,
    )
