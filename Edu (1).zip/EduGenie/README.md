# EduGenie — Google Gemini Powered Learning Assistant

EduGenie is a lightweight AI learning assistant based on the supplied project documentation. It provides:

- Q&A
- Simplified concept explanations
- 3-question MCQ generation
- Educational summarization
- Personalized learning paths

## Architecture

FastAPI serves both the REST API and the HTML/CSS frontend.

Core modules:

- `main.py` — FastAPI application and API routes
- `gemini_client.py` — shared Google Gemini client
- `qna.py` — question answering
- `explanation_module.py` — concept explanations with optional local LaMini model
- `quiz_module.py` — structured 3-question MCQ generation
- `summary_module.py` — summarization
- `learning_path.py` — personalized learning recommendations
- `templates/index.html` — web interface
- `static/style.css` — styling

## Quick start

### 1. Create a virtual environment

Windows:

```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install packages

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 3. Configure Gemini

Copy `.env.example` to `.env` and set:

```env
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-3.8-flash
USE_LOCAL_EXPLAINER=false
```

### 4. Start the server

```bash
uvicorn main:app --reload
```

Open:

http://127.0.0.1:8000

API documentation:

http://127.0.0.1:8000/docs

Health check:

http://127.0.0.1:8000/health

## Optional local explanation model

The original documentation specifies LaMini-Flan-T5 for explanations.

To enable the optional local model:

```bash
pip install -r requirements-local.txt
```

Then set:

```env
USE_LOCAL_EXPLAINER=true
```

The first use downloads the model. This requires substantially more disk space and memory than the default Gemini-only setup.

If local loading fails, EduGenie automatically falls back to Gemini.

## API examples

### Q&A

```bash
curl -X POST http://127.0.0.1:8000/qa ^
  -H "Content-Type: application/json" ^
  -d "{\"question\":\"Which is the largest ocean?\"}"
```

### Explain

```bash
curl -X POST http://127.0.0.1:8000/explain ^
  -H "Content-Type: application/json" ^
  -d "{\"text\":\"Explain the Pythagoras theorem simply.\"}"
```

### Quiz

```bash
curl -X POST http://127.0.0.1:8000/quiz ^
  -H "Content-Type: application/json" ^
  -d "{\"text\":\"Water covers most of Earth's surface and exists as solid, liquid and gas.\"}"
```

### Summary

```bash
curl -X POST http://127.0.0.1:8000/summarize ^
  -H "Content-Type: application/json" ^
  -d "{\"text\":\"Paste a long educational passage here.\"}"
```

### Learning path

```bash
curl -X POST http://127.0.0.1:8000/learn/recommendations ^
  -H "Content-Type: application/json" ^
  -d "{\"topic\":\"SQL\",\"level\":\"Beginner\"}"
```

## Troubleshooting

### `GEMINI_API_KEY is missing`

Make sure `.env` exists beside `main.py` and contains a valid key.

### Model not found

Set `GEMINI_MODEL` in `.env` to a Gemini model available to your API project.

### Port already in use

Run:

```bash
uvicorn main:app --reload --port 8001
```

Then open:

http://127.0.0.1:8001

## Security

Do not commit `.env` to Git. `.gitignore` already excludes it.

For production, add authentication, rate limiting, request logging, stricter input limits, and secret management before exposing the API publicly.
## Premium interface

The frontend includes a responsive premium dark learning-studio interface with a sidebar workspace, AI status indicators, animated visual treatment, task cards, an interactive composer, copy action, and interactive quiz answers. No extra frontend package or build step is required.
